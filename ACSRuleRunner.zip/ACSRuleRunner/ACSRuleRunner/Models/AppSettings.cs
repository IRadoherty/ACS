﻿
public class AppSettings
{
    public ConnectionStrings ConnectionStrings { get; set; }
    public InRule InRule { get; set; }
    public Timer Timer { get; set; }
    public string JsonDirectory { get; set; }
    public string OutputTableName { get; set; }
    public int RequestsAtOneTime { get; set; }
    public bool PerformWarmUp { get; set; }
    public int BatchSize { get; set; }
    public int DatabaseBatchSize { get; set; }
    public int InRuleMessageSize { get; set; }
    public int MaxRetries { get; set; }
}



public class ConnectionStrings
{
    public string Default { get; set; }
}

public class Development
{
    public string ExecutionServiceUrl { get; set; }
    public string ApiKey { get; set; }
}

public class InRule
{
    public InRuleProfessionalServices InRuleProfessionalServices { get; set; }
    public Development Development { get; set; }
    public Production Production { get; set; }
    public ProcessQualityMeasuresRCRS ProcessQualityMeasuresRCRS { get; set; }

}

public class InRuleProfessionalServices
{
    public string ExecutionServiceUrl { get; set; }
    public string ApiKey { get; set; }
    public string? Label { get; set; }
    public int? Revision { get; set; }
}


public class ProcessQualityMeasuresRCRS
{
    public string RuleApplicationName { get; set; }
    public string DecisionName { get; set; }
    public string? Label { get; set; }
    public int? Revision { get; set; }
}

public class Production
{
    public string ExecutionServiceUrl { get; set; }
    public string ApiKey { get; set; }
    public string? Label { get; set; }
    public int? Revision { get; set; }
}



public class Timer
{
    public int Milliseconds { get; set; }
    public int Seconds { get; set; }
}
