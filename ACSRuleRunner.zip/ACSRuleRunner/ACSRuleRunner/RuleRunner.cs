﻿using System.Diagnostics;
using ACSTestHarness.DataAccess;
using ACSTestHarness.Services;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

namespace ACSTestHarness;

public class RuleRunner
{
    public static AppSettings AppSettings = Program.AppSettings;

    private readonly ILogger<RuleRunner> _logger;
    private readonly IBatchService _batchService;
    protected RuleRunnerDbContext _db;
    private readonly int _databaseBatchSize = AppSettings.DatabaseBatchSize;
    
    public RuleRunner(ILogger<RuleRunner> logger, IBatchService batchService, RuleRunnerDbContext db)
    {
        _logger = logger;
        _batchService = batchService;
        _db = db;
    }

    private readonly PeriodicTimer _timer = new(TimeSpan.FromMilliseconds(AppSettings.Timer.Milliseconds));
    public void StartRuleRunner(bool enabled, CancellationToken cancellationToken)
    {
        Task.Run(async () => await RunRuleRunner(enabled, cancellationToken), cancellationToken);
    }

    private async ValueTask RunRuleRunner(bool enabled, CancellationToken cancellationToken)
    {
        while (await _timer.WaitForNextTickAsync(cancellationToken))
        {
            try
            {
                if (enabled) // disable when starting to stop next tick from running the process again
                    enabled = false;

                var watch = new Stopwatch(); var runWatch = new Stopwatch();
                watch.Start(); runWatch.Start();

                int caseStartNumber = 0, casesStopNumber;
                int caseCount = await _db.Cases.CountAsync(cancellationToken);
                if (caseCount == 0)
                {
                    _logger.LogInformation("{RuleRunner} has no cases to process", nameof(RuleRunner));
                    continue;
                }

                _logger.LogInformation("{RuleRunner} has {CaseCount} cases to process", nameof(RuleRunner), caseCount);
                int runNumber = 0;
                while (caseStartNumber < caseCount)
                {
                    runNumber++;
                    casesStopNumber = caseStartNumber + _databaseBatchSize;
                    if (casesStopNumber > caseCount)
                        casesStopNumber = caseCount;
                    _logger.LogInformation("Pulling from database..");

                    var dbWatch = new Stopwatch();
                    var cases = await _db.Cases
                        .Where(caseRecord => caseRecord.Id > caseStartNumber && caseRecord.Id <= casesStopNumber).ToListAsync(cancellationToken: cancellationToken);
                    
                    _logger.LogInformation("Database run took: {dbWatch}", dbWatch.Elapsed);
                    dbWatch.Stop();
                    // The below is to trim white space from db fields that are strings
                    foreach (var item in cases)
                    {
                        foreach (var property in item.GetType().GetProperties())
                        {
                            if (property.PropertyType != typeof(string))
                                continue;
                            var currentValue = (string)property.GetValue(item)!;
                            if (currentValue is not null)
                                property.SetValue(item, currentValue.Trim());
                        }
                    }

                    _logger.LogInformation("{RuleRunner} is running cases {caseStartNumber} through {casesStopNumber} of {caseCount} for run {runNumber}. {NewLine} ElapsedTime: {ElapsedTime}", nameof(RuleRunner), caseStartNumber, casesStopNumber, caseCount, runNumber, Environment.NewLine, watch.Elapsed);
                    
                    await _batchService.ExecuteBatch(cases, runNumber, caseStartNumber);

                    _logger.LogInformation("{RuleRunner} completed run for cases {caseStartNumber} through {casesStopNumber} of {caseCount} {NewLine} ElapsedTime: {watch} {NewLine} Run time: {runWatch}", 
                        nameof(RuleRunner),
                        caseStartNumber, 
                        casesStopNumber, 
                        caseCount, 
                        Environment.NewLine, 
                        watch.Elapsed, 
                        Environment.NewLine, 
                        runWatch.Elapsed);

                    runWatch.Stop();
                    caseStartNumber = casesStopNumber;
                }
                watch.Stop();
                _logger.LogInformation("{RuleRunner} completed in {Elapsed}", nameof(RuleRunner), watch.Elapsed);
            }
            catch (Exception e)
            {
                _logger.LogInformation("{RuleRunner} encountered an error: {Message}", nameof(RuleRunner), e.Message);
            }
        }
    }
}


