﻿using System.Collections.Concurrent;
using ACSTestHarness.DataAccess;
using ACSTestHarness.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Message = System.Collections.Generic.KeyValuePair<int, System.Collections.Generic.List<ACSTestHarness.Models.MeshTable>>;

namespace ACSTestHarness.Services;

public interface IBatchService
{
    Task ExecuteBatch(List<Case> cases, int runNumber, int caseStartNumber);
}

public class BatchService : IBatchService
{
    private readonly ILogger<BatchService> _logger;
    private readonly IInRuleSaaSExecutionService _inRuleExecutionService;
    private readonly IBulkCopy _bulkCopy;
    protected RuleRunnerDbContext _db;
    private static readonly AppSettings AppSettings = Program.AppSettings;
    private readonly int _inRuleMessageSize = AppSettings.InRuleMessageSize;
    private readonly SemaphoreSlim _semaphore = new(AppSettings.RequestsAtOneTime, AppSettings.RequestsAtOneTime);
    private ConcurrentQueue<Message> _messages = new();

    public BatchService(ILogger<BatchService> logger, IInRuleSaaSExecutionService inRuleSaaSExecutionService, RuleRunnerDbContext db, IBulkCopy bulkCopy)
    {
        _logger = logger;
        _inRuleExecutionService = inRuleSaaSExecutionService;
        _db = db;
        _bulkCopy = bulkCopy;
    }
    public async Task ExecuteBatch(List<Case> cases, int runNumber, int caseStartNumber)
    {
        try
        {
            int batchCount = 0;
            List<Task> tasks = new();
            var caseCount = cases.Count + caseStartNumber;
            while (caseStartNumber < caseCount)
            {
                batchCount++;
                var caseBatch = cases.Where(caseRecord => caseRecord.Id > caseStartNumber && caseRecord.Id <= caseStartNumber + _inRuleMessageSize).ToList();
                tasks.Add(ExecuteDecision(caseBatch, batchCount));
                caseStartNumber += _inRuleMessageSize;
            }

            await Task.WhenAll(tasks);

            List<MeshTable>? meshTable = new();
            while (_messages.TryDequeue(out var msg))
            {
                meshTable.AddRange(msg.Value);
            }
            // this is the output to the DB using an output table
            if (meshTable is not null)
                await _bulkCopy.BulkUpdateOutputTable(meshTable);

            _logger.LogInformation("Completed database run {RunNumber} with {BatchCount} batches", runNumber, batchCount);
        }
        catch (Exception ex) //some other exception
        {
            _logger.LogError("Error creating tasks: {Message}", ex.Message);
        }
    }
    public async Task ExecuteDecision(List<Case> cases, int batchCount)
    {
        try
        {
            await _semaphore.WaitAsync();
            _logger.LogInformation("Started execution request");
            MeasureRecordModel measureRecord = new()
            {
                MeasureRecord = new MeasureRecord() { Cases = cases }
            };
            var decisionRequest = await CreateDecisionRequest(JsonConvert.SerializeObject(measureRecord));
            var responseString = await _inRuleExecutionService.ExecuteDecision(decisionRequest);
            var executeDecisionResponse = JsonConvert.DeserializeObject<ExecuteDecisionResponse>(responseString);
            var meshTableList = JsonConvert.DeserializeObject<MeshTableList>(executeDecisionResponse.OutputState);
            if (meshTableList.MeshTable is not null)
            {
                _messages.Enqueue(new Message(batchCount, meshTableList.MeshTable));
                _logger.LogInformation("Completed execution request");
            }
            else
            {
                _logger.LogInformation("Found null response for case and did not add to queue");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError("Error executing batch: {Message}", ex.Message);
        }
        finally
        {
            _semaphore.Release();
        }
    }

    private static async ValueTask<ExecuteDecisionRequest> CreateDecisionRequest(string inputState)
    {
        var label = AppSettings.InRule.ProcessQualityMeasuresRCRS.Label;
        if (label == "")
            label = null;
        var executeDecisionRequest = new ExecuteDecisionRequest
        {
            RuleApp = new RuleApp
            {
                RepositoryRuleAppRevisionSpec = new RepositoryRuleAppRevisionSpec()
                {
                    RuleApplicationName =
                        AppSettings.InRule.ProcessQualityMeasuresRCRS.RuleApplicationName,
                    Label = label,
                    Revision = AppSettings.InRule.ProcessQualityMeasuresRCRS.Revision
                }
            },
            DecisionName = AppSettings.InRule.ProcessQualityMeasuresRCRS.DecisionName,
            InputState = inputState
        };
        return executeDecisionRequest;
    }
}
