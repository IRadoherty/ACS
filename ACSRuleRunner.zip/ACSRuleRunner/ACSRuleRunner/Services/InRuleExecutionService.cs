﻿using System.Net.Http.Headers;
using System.Text;
using ACSTestHarness.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Polly;
using Polly.Retry;

namespace ACSTestHarness.Services
{
    public interface IInRuleSaaSExecutionService
    {
        Task<string> ExecuteDecision(ExecuteDecisionRequest executeDecisionRequest);
    }
    public class InRuleSaaSExecutionService : IInRuleSaaSExecutionService
    {
        private static readonly AppSettings AppSettings = Program.AppSettings;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ILogger<InRuleSaaSExecutionService> _logger;
        private readonly AsyncRetryPolicy<HttpResponseMessage> _retryPolicy;
        public InRuleSaaSExecutionService(IHttpClientFactory httpClientFactory, ILogger<InRuleSaaSExecutionService> logger)
        {
            _httpClientFactory = httpClientFactory;
            _logger = logger;
            _retryPolicy = Policy<HttpResponseMessage>.Handle<HttpRequestException>().RetryAsync(AppSettings.MaxRetries);
        }
        public async Task<string> ExecuteDecision(ExecuteDecisionRequest executeDecisionRequest)
        {
            try
            {
                var httpClient = _httpClientFactory.CreateClient("ExecuteDecision");
                var requestJson = JsonConvert.SerializeObject(executeDecisionRequest);
                var content = new StringContent(requestJson, Encoding.UTF8, "application/json");
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                var response = await _retryPolicy.ExecuteAsync(async () =>
                    await httpClient.PostAsync(AppSettings.InRule.InRuleProfessionalServices.ExecutionServiceUrl,
                        content));
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception e)
            {
                _logger.LogInformation("Error during execution : {Message}", e.Message);
            }
            return "Error";
        }
    }
}
