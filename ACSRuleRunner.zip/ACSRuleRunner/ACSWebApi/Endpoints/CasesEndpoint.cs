﻿using System.Reflection.Metadata.Ecma335;
using System.Runtime.Serialization;
using ACSTestHarness.DataAccess;
using ACSTestHarness.Models;
using EFCore.BulkExtensions;
using Microsoft.EntityFrameworkCore;

namespace ACSWebApi.Endpoints;
public static class CaseEndpoint
{
    public static void StartCaseEndpoint(this WebApplication app)
    {
        app.MapGet("/GetCases", GetCases);
        app.MapGet("/GetCase/{RECORD_ID}", GetCase);
        app.MapPost("/InsertCase", InsertCase);
        app.MapPost("/InsertCases", InsertCases);
        app.MapPut("/UpdateCase/{RECORD_ID}", UpdateCase);
        app.MapDelete("/DeleteCase", DeleteCase);

    }
    private static async Task<IResult> GetCases(RuleRunnerDbContext context)
    {
        return Results.Ok(await context.Cases.ToListAsync());
    }
    private static async Task<IResult> GetCase(RuleRunnerDbContext context, int RECORD_ID)
    {
        return await context.Cases.FindAsync(RECORD_ID) is { } caseRecord
            ? Results.Ok(caseRecord)
            : Results.NotFound("Not Found");
    }
    private static async Task<IResult> InsertCase(RuleRunnerDbContext context, Case caseRecord)
    {
        context.Add(caseRecord);
        return Results.Ok(await context.SaveChangesAsync());
    }
    private static async Task<IResult> InsertCases(RuleRunnerDbContext context, List<Case> caseRecordList)
    {
        try
        {
            List<Case> caseList = new();
            for (int j = 1; j < 200; j++)
            {
                var h = 1000 * j;
                var i = 327000 + h;
                for (int a = 0; a < caseRecordList.Count; a++)
                {

                    caseRecordList[a].Id = i;
                    caseList.Add(caseRecordList[a]);
                    i++;
                }

            }
            await context.BulkInsertAsync(caseList);
            return Results.Ok();
        }
        catch(Exception e)
        {
            return Results.Problem(e.Message);
        }

    }
    private static async Task<IResult> UpdateCase(RuleRunnerDbContext context, Case caseRecord, int RECORD_ID)
    {
        var dbCaseRecord = await context.Cases.FindAsync(RECORD_ID);
        if (dbCaseRecord is null) return Results.NotFound("Not Found");

        dbCaseRecord = caseRecord;
        await context.SaveChangesAsync();
        return Results.Ok(await context.SaveChangesAsync());
    }
    private static async Task<IResult> DeleteCase(RuleRunnerDbContext context, int RECORD_ID)
    {
        var dbCaseRecord = await context.Cases.FindAsync(RECORD_ID);
        if (dbCaseRecord is null) return Results.NotFound("Not Found");

        context.Cases.Remove(dbCaseRecord);

        return Results.Ok(await context.SaveChangesAsync());
    }

}

