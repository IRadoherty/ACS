﻿using System.Reflection.Metadata.Ecma335;
using System.Runtime.Serialization;
using ACSTestHarness.DataAccess;
using ACSTestHarness.Models;
using Microsoft.EntityFrameworkCore;

namespace ACSWebApi.Endpoints;
public static class MeshTableEndpoint
{
    public static void StartMeshTableEndpoint(this WebApplication app)
    {
        app.MapGet("/GetMeshTables", GetMeshTables);
        app.MapGet("/GetMeshTable/{MEASURE_KEY}", GetMeshTable);
        app.MapPost("/InsertMeshTable", InsertMeshTable);
        app.MapPut("/UpdateMeshTable/{MEASURE_KEY}", UpdateMeshTable);
        app.MapDelete("/DeleteMeshTable", DeleteMeshTable);

    }
    private static async Task<IResult> GetMeshTables(RuleRunnerDbContext context)
    {
        return Results.Ok(await context.MeshTable.ToListAsync());
    }
    private static async Task<IResult> GetMeshTable(RuleRunnerDbContext context, int MEASURE_KEY)
    {
        return await context.MeshTable.FindAsync(MEASURE_KEY) is { } MeshTableRecord
            ? Results.Ok(MeshTableRecord)
            : Results.NotFound("Not Found");
    }
    private static async Task<IResult> InsertMeshTable(RuleRunnerDbContext context, MeshTable MeshTableRecord)
    {
        context.Add(MeshTableRecord);
        return Results.Ok(await context.SaveChangesAsync());
    }
    private static async Task<IResult> UpdateMeshTable(RuleRunnerDbContext context, MeshTable MeshTableRecord, int MEASURE_KEY)
    {
        var dbMeshTableRecord = await context.MeshTable.FindAsync(MEASURE_KEY);
        if (dbMeshTableRecord is null) return Results.NotFound("Not Found");

        dbMeshTableRecord = MeshTableRecord;
        await context.SaveChangesAsync();
        return Results.Ok(await context.SaveChangesAsync());
    }
    private static async Task<IResult> DeleteMeshTable(RuleRunnerDbContext context, int MEASURE_KEY)
    {
        var dbMeshTableRecord = await context.MeshTable.FindAsync(MEASURE_KEY);
        if (dbMeshTableRecord is null) return Results.NotFound("Not Found");

        context.MeshTable.Remove(dbMeshTableRecord);

        return Results.Ok(await context.SaveChangesAsync());
    }

}

