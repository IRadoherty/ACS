﻿using ACSTestHarness.DataAccess;
using ACSWebApi.Endpoints;
using Microsoft.EntityFrameworkCore;
using Serilog;

    var builder = WebApplication.CreateBuilder(args);

    var logger = new LoggerConfiguration()
        .ReadFrom.Configuration(builder.Configuration)
        .Enrich.FromLogContext()
        .WriteTo.Console()
        .CreateLogger();
    //builder.Logging.ClearProviders();
    builder.Logging.AddSerilog(logger);


    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();
    builder.Services.AddCors();
    builder.Services.AddDbContext<RuleRunnerDbContext>(options =>
    {
        options.EnableDetailedErrors();
        options.EnableSensitiveDataLogging();
        options.UseSqlServer(builder.Configuration.GetConnectionString("Default"));
    });
        
    var app = builder.Build();

    app.UseCors(b => b.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
    app.UseHttpsRedirection();
    app.UseStaticFiles();


    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI(o => o.DisplayRequestDuration());
    }

    app.StartCaseEndpoint();
    app.StartMeshTableEndpoint();

    

    app.Run();
    Log.Information("API Started");


