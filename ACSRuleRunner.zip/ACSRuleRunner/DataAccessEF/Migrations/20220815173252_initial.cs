﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DataAccessEF.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Cases",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RECORD_ID = table.Column<int>(type: "int", nullable: false),
                    DX_DATE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ACCESSION_NR = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DX_YEAR = table.Column<int>(type: "int", nullable: false),
                    FACILITY_ID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AGE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BIRTH_DATE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BEHAVIOR_ICDO3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BOOST_RX_MODALITY = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BRM_DT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CHEMO_DT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CLASS_OF_CASE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CLIN_STAGE_GROUP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CNCR_DIR_SURGERY_DT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CS_SSF_1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CS_SSF_2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CS_SSF_6 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CS_SSF_8 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CS_SSF_15 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CS_SSF_25 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CS_TUMOR_SIZE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GRADE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HISTOLOGY_ICDO3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HORMONE_DT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LAST_CONTACT_DT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LATERALITY = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LOC_OF_RADIATION = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NAACCR_VERSION = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PALLIATIVE_PROC = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PATH_STAGE_GROUP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PRIMARY_SITE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RADIATION_DT = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RADIATION_REG_RX_MOD = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RADIATION_RX_VOL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    REASON_NO_CNCR_SURGERY = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    REASON_NO_RADIATION = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    REG_NODES_EXAM = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    REG_NODES_POS = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RX_DATE_DX_STG_PROC = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RX_DATE_MOST_DEFIN_SURG = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RX_DATE_RAD_ENDED = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RX_DATE_SYSTEMIC = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RX_HOSP_SURG_APP_2010 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SCOPE_REG_LN_SRGY_03 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SEQUENCE_NBR = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SEX = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SRGY_PRIMARY_SITE_03 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SUMM_BRM = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SUMM_CHEMO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SUMM_HORMONE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SUMM_NO_CNCR_SURGERY = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SUMM_PALLIATIVE_PROC = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SUMM_SRGY_PRIMARY_SITE_03 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SUMM_SURGICAL_MARGINS = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TNM_CLIN_M = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TNM_CLIN_N = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TNM_CLIN_T = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TNM_PATH_M = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TNM_PATH_N = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TNM_PATH_T = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VITAL_STATUS = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TUMOR_SIZE_SUMMARY = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_PATH_T = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_PATH_N = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_PATH_M = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_PATH_STG_GRP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_CLIN_T = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_CLIN_N = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_CLIN_M = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_CLIN_STG_GRP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_POST_M = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_POST_N = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_POST_STG_GRP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AJCC_TNM_POST_T = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HER2_OVERALL_SUMM = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ER_SUMMARY = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PR_SUMMARY = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ER_PERCENT_POS_OR_RNG = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PR_PERCENT_POS_OR_RNG = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PHASE_I_RT_MODALITY = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PHASE_II_RT_MODALITY = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PHASE_I_RT_VOLUME = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PHASE_I_BEAM_TECH = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PHASE_I_RT_TO_LN = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FIGO_STAGE = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SCHEMA_DISC_1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PSA = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GLEASON_SCORE_CLIN = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CRM = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SLN_POS = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NUM_PELV_NODES_POS = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BRESLOW_THICKNESS = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LN_FEM_ING_PARA_APELV = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GRADE_CLIN = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SCHEMA_DISC_2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SUMM_SYS_SEQ = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SUMM_SR_SEQ = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cases", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MeshTable",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MEASURE_KEY = table.Column<int>(type: "int", nullable: false),
                    FACILITY_ID = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DX_YEAR = table.Column<int>(type: "int", nullable: false),
                    SEQUENCE_NBR = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PRIMARY_SITE = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MeshTable", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Cases");

            migrationBuilder.DropTable(
                name: "MeshTable");
        }
    }
}
