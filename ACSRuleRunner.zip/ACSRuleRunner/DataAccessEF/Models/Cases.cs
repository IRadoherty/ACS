﻿
namespace ACSTestHarness.Models;

public class MeasureRecordModel
{
    public MeasureRecord? MeasureRecord { get; set; }
}

public class MeasureRecord
{
    public List<Case>? Cases { get; set; }
}
public class Case
{
    public int Id { get; set; }
    public int RECORD_ID { get; set; }
    public string? DX_DATE { get; set; }
    public string? ACCESSION_NR { get; set; }
    public int DX_YEAR { get; set; }
    public string? FACILITY_ID { get; set; }
    public string? AGE { get; set; }
    public string? BIRTH_DATE { get; set; }
    public string? BEHAVIOR_ICDO3 { get; set; }
    public string? BOOST_RX_MODALITY { get; set; }
    public string? BRM_DT { get; set; }
    public string? CHEMO_DT { get; set; }
    public string? CLASS_OF_CASE { get; set; }
    public string? CLIN_STAGE_GROUP { get; set; }
    public string? CNCR_DIR_SURGERY_DT { get; set; }
    public string? CS_SSF_1 { get; set; }
    public string? CS_SSF_2 { get; set; }
    public string? CS_SSF_6 { get; set; }
    public string? CS_SSF_8 { get; set; }
    public string? CS_SSF_15 { get; set; }
    public string? CS_SSF_25 { get; set; }
    public string? CS_TUMOR_SIZE { get; set; }
    public string? GRADE { get; set; }
    public string? HISTOLOGY_ICDO3 { get; set; }
    public string? HORMONE_DT { get; set; }
    public string? LAST_CONTACT_DT { get; set; }
    public string? LATERALITY { get; set; }
    public string? LOC_OF_RADIATION { get; set; }
    public string? NAACCR_VERSION { get; set; }
    public string? PALLIATIVE_PROC { get; set; }
    public string? PATH_STAGE_GROUP { get; set; }
    public string? PRIMARY_SITE { get; set; }
    public string? RADIATION_DT { get; set; }
    public string? RADIATION_REG_RX_MOD { get; set; }
    public string? RADIATION_RX_VOL { get; set; }
    public string? REASON_NO_CNCR_SURGERY { get; set; }
    public string? REASON_NO_RADIATION { get; set; }
    public string? REG_NODES_EXAM { get; set; }
    public string? REG_NODES_POS { get; set; }
    public string? RX_DATE_DX_STG_PROC { get; set; }
    public string? RX_DATE_MOST_DEFIN_SURG { get; set; }
    public string? RX_DATE_RAD_ENDED { get; set; }
    public string? RX_DATE_SYSTEMIC { get; set; }
    public string? RX_HOSP_SURG_APP_2010 { get; set; }
    public string? SCOPE_REG_LN_SRGY_03 { get; set; }
    public string? SEQUENCE_NBR { get; set; }
    public string? SEX { get; set; }
    public string? SRGY_PRIMARY_SITE_03 { get; set; }
    public string? SUMM_BRM { get; set; }
    public string? SUMM_CHEMO { get; set; }
    public string? SUMM_HORMONE { get; set; }
    public string? SUMM_NO_CNCR_SURGERY { get; set; }
    public string? SUMM_PALLIATIVE_PROC { get; set; }
    public string? SUMM_SRGY_PRIMARY_SITE_03 { get; set; }
    public string? SUMM_SURGICAL_MARGINS { get; set; }
    public string? TNM_CLIN_M { get; set; }
    public string? TNM_CLIN_N { get; set; }
    public string? TNM_CLIN_T { get; set; }
    public string? TNM_PATH_M { get; set; }
    public string? TNM_PATH_N { get; set; }
    public string? TNM_PATH_T { get; set; }
    public string? VITAL_STATUS { get; set; }
    public string? TUMOR_SIZE_SUMMARY { get; set; }
    public string? AJCC_TNM_PATH_T { get; set; }
    public string? AJCC_TNM_PATH_N { get; set; }
    public string? AJCC_TNM_PATH_M { get; set; }
    public string? AJCC_TNM_PATH_STG_GRP { get; set; }
    public string? AJCC_TNM_CLIN_T { get; set; }
    public string? AJCC_TNM_CLIN_N { get; set; }
    public string? AJCC_TNM_CLIN_M { get; set; }
    public string? AJCC_TNM_CLIN_STG_GRP { get; set; }
    public string? AJCC_TNM_POST_M { get; set; }
    public string? AJCC_TNM_POST_N { get; set; }
    public string? AJCC_TNM_POST_STG_GRP { get; set; }
    public string? AJCC_TNM_POST_T { get; set; }
    public string? HER2_OVERALL_SUMM { get; set; }
    public string? ER_SUMMARY { get; set; }
    public string? PR_SUMMARY { get; set; }
    public string? ER_PERCENT_POS_OR_RNG { get; set; }
    public string? PR_PERCENT_POS_OR_RNG { get; set; }
    public string? PHASE_I_RT_MODALITY { get; set; }
    public string? PHASE_II_RT_MODALITY { get; set; }
    public string? PHASE_I_RT_VOLUME { get; set; }
    public string? PHASE_I_BEAM_TECH { get; set; }
    public string? PHASE_I_RT_TO_LN { get; set; }
    public string? FIGO_STAGE { get; set; }
    public string? SCHEMA_DISC_1 { get; set; }
    public string? PSA { get; set; }
    public string? GLEASON_SCORE_CLIN { get; set; }
    public string? CRM { get; set; }
    public string? SLN_POS { get; set; }
    public string? NUM_PELV_NODES_POS { get; set; }
    public string? BRESLOW_THICKNESS { get; set; }
    public string? LN_FEM_ING_PARA_APELV { get; set; }
    public string? GRADE_CLIN { get; set; }
    public string? SCHEMA_DISC_2 { get; set; }
    public string? SUMM_SYS_SEQ { get; set; }
    public string? SUMM_SR_SEQ { get; set; }
}

