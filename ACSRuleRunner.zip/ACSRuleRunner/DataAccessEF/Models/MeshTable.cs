﻿using System.ComponentModel.DataAnnotations;

namespace ACSTestHarness.Models;


public class MeshTableList
{
    public List<MeshTable>? MeshTable { get; set; }
}
public class MeshTable
{
    public int Id { get; set; }
    public int MEASURE_KEY { get; set; }
    public string? FACILITY_ID { get; set; }
    public int DX_YEAR { get; set; }
    public string? SEQUENCE_NBR { get; set; }
    public string? PRIMARY_SITE { get; set; }
}
