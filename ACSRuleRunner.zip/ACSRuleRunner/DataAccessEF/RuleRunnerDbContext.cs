﻿using ACSTestHarness.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace ACSTestHarness.DataAccess;


public class RuleRunnerDbContext : DbContext
{
    public RuleRunnerDbContext(DbContextOptions<RuleRunnerDbContext> options) : base(options)
    {

    }
    public DbSet<Case>? Cases { get; set; }
    public DbSet<MeshTable>? MeshTable { get; set; }
}

