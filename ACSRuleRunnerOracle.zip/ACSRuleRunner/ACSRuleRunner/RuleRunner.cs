﻿using System.Data;
using System.Diagnostics;
using System.Reflection;
using ACSRuleRunner.Services;
using DataAccess.DbAccess;
using Microsoft.Extensions.Logging;

namespace ACSRuleRunner;

public class RuleRunner
{
    public static AppSettings AppSettings = Program.AppSettings;

    private readonly ILogger<RuleRunner> _logger;
    private readonly IBatchService _batchService;
    private readonly IOracleManager _oracleManager;
    private readonly int _databaseBatchSize = AppSettings.DatabaseBatchSize;

    public RuleRunner(ILogger<RuleRunner> logger, IBatchService batchService, IOracleManager oracleManager)
    {
        _logger = logger;
        _batchService = batchService;
        _oracleManager = oracleManager;
    }

    private readonly PeriodicTimer _timer = new(TimeSpan.FromMilliseconds(AppSettings.Timer.Milliseconds));
    public void StartRuleRunner(bool enabled, CancellationToken cancellationToken)
    {
        Task.Run(async () => await RunRuleRunner(enabled, cancellationToken), cancellationToken);
    }

    private async Task RunRuleRunner(bool enabled, CancellationToken cancellationToken)
    {
        while (await _timer.WaitForNextTickAsync(cancellationToken))
        {
            try
            {
                if (enabled) // disable on starting to stop next tick from running the process while it's already running
                    enabled = false;

                var elapsedTime = new Stopwatch(); var runTime = new Stopwatch();
                elapsedTime.Start(); runTime.Start();

                // Get case count from database
                var totalCases = _oracleManager.GetCaseCount("NEW");

                if (totalCases == 0)
                {
                    _logger.LogInformation("{RuleRunner} has no cases to process", nameof(RuleRunner));
                    continue;
                }

                _logger.LogInformation("{RuleRunner} has {totalCases} cases to process", nameof(RuleRunner),
                    totalCases);

                int casesPulled = 0, runNumber = 0;
                while (casesPulled <= totalCases)
                {
                    runNumber++;
                    _logger.LogInformation("Pulling from database..");

                    var caseData = _oracleManager.GetCaseData(_databaseBatchSize, "NEW");
                    casesPulled += caseData.Count;
                    int remainingCases = totalCases - casesPulled;

                    _logger.LogInformation("{RuleRunner} is running {caseDataCount} cases..", nameof(RuleRunner),
                        caseData.Count);
                    var meshTable = await _batchService.ExecuteBatch(caseData, runNumber);

                    if (meshTable.Count is not 0)
                    {
                        try
                        {
                            _oracleManager.InsertMeshTableBulk(meshTable);
                            _oracleManager.UpdateSnapShotCases(meshTable, "DONE");

                            _logger.LogInformation(
                                "{RuleRunner} completed run {runNumber} with no errors for {casesPulled} out of {caseCount} cases with {remainingCases} remaining {NewLine} Run time: {runTime} {NewLine} Elapsed time: {elapsedTime} ",
                                nameof(RuleRunner), runNumber, casesPulled, totalCases, remainingCases,
                                Environment.NewLine, runTime.Elapsed, Environment.NewLine, elapsedTime.Elapsed);
                        }
                        catch
                        {
                            int casesUpdatedSuccessfully = 0, casesUpdatedWithError = 0;
                            _logger.LogInformation("Error bulk inserting database, trying single updates now..");
                            foreach (var meshData in meshTable)
                            {
                                try
                                {
                                    _oracleManager.InsertMeshTableSingle(meshData);
                                    _oracleManager.UpdateSnapShotCase(meshData, "DONE");
                                    _logger.LogInformation("Inserted case successfully");
                                    ++casesUpdatedSuccessfully;
                                }
                                catch (Exception ex)
                                {
                                    _oracleManager.UpdateSnapShotCase(meshData, "ERROR");
                                    _logger.LogInformation(
                                        "Unable to insert case: {caseNumber} so changed status to error, {ex}",
                                        meshData.MASTER_CASE_RECORD_ID, ex);
                                    ++casesUpdatedWithError;
                                }
                            }

                            _logger.LogInformation(
                                "Successfully inserted {casesUpdatedSuccessfully} records and {casesUpdatedWithError} with errors",
                                casesUpdatedSuccessfully, casesUpdatedWithError);
                            _logger.LogInformation(
                                "{RuleRunner} completed run {runNumber} with errors for {casesPulled} out of {totalCases} cases with {remainingCases} remaining {NewLine} Run time: {runTime} {NewLine} Elapsed time: {elapsedTime} ",
                                nameof(RuleRunner), runNumber, casesPulled, totalCases, remainingCases,
                                Environment.NewLine, runTime.Elapsed, Environment.NewLine, elapsedTime.Elapsed);
                        }
                    }
                    runTime.Stop();
                }
                elapsedTime.Stop();
                _logger.LogInformation("{RuleRunner} completed in {Elapsed}", nameof(RuleRunner), elapsedTime.Elapsed);

                if (casesPulled >= totalCases)
                {
                    enabled = true;
                    break;
                }
            }
            catch (Exception e)
            {
                _logger.LogInformation("{RuleRunner} encountered an error: {Message}", nameof(RuleRunner), e.Message);
                enabled = true;
            }
        }
    }
}
