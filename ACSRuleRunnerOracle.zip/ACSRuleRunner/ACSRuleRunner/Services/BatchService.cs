﻿using System.Collections.Concurrent;
using ACSRuleRunner.Models;
using DataAccess.Models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Message = System.Collections.Generic.KeyValuePair<int, System.Collections.Generic.List<DataAccess.Models.MeshTable>>;

namespace ACSRuleRunner.Services;

public interface IBatchService
{
    Task<List<MeshTable>> ExecuteBatch(List<Cases> cases, int runNumber);
}

public class BatchService : IBatchService
{
    private readonly ILogger<BatchService> _logger;
    private readonly IInRuleSaaSExecutionService _inRuleExecutionService;
    private static readonly AppSettings AppSettings = Program.AppSettings;
    private int _inRuleMessageSize = AppSettings.InRuleMessageSize;
    private readonly SemaphoreSlim _semaphore = new(AppSettings.RequestsAtOneTime, AppSettings.RequestsAtOneTime);
    private ConcurrentQueue<Message> _messages = new();

    public BatchService(ILogger<BatchService> logger, IInRuleSaaSExecutionService inRuleSaaSExecutionService)
    {
        _logger = logger;
        _inRuleExecutionService = inRuleSaaSExecutionService;
    }
    public async Task<List<MeshTable>> ExecuteBatch(List<Cases> cases, int runNumber)
    {
        List<MeshTable> meshTable = new();
        try
        {
            int batchCount = 0, index = 0;
            List<Task> tasks = new();
            while (index < cases.Count)
            {
                ++batchCount;
                int remainingCases = cases.Count - index;
                tasks.Add(remainingCases >= _inRuleMessageSize
                    ? ExecuteDecision(cases.GetRange(index, _inRuleMessageSize), runNumber + batchCount)
                    : ExecuteDecision(cases.GetRange(index, remainingCases), runNumber + batchCount));
                index += _inRuleMessageSize;
            }

            await Task.WhenAll(tasks);

            while (_messages.TryDequeue(out var msg))
            {
                meshTable.AddRange(msg.Value);
            }
            return meshTable;
        }
        catch (Exception ex)
        {
            _logger.LogError("Error creating batch tasks: {Message}", ex.Message);
        }
        return meshTable;
    }
    public async Task ExecuteDecision(List<Cases> cases, int batchCount)
    {
        try
        {
            await _semaphore.WaitAsync();
            _logger.LogInformation("Started execution request");
            MeasureRecordModel measureRecord = new(){ MeasureRecord = new MeasureRecord() { Cases = cases }};
            var decisionRequest = CreateDecisionRequest(JsonConvert.SerializeObject(measureRecord));
            var responseString = await _inRuleExecutionService.ExecuteDecision(decisionRequest);
            var executeDecisionResponse = JsonConvert.DeserializeObject<ExecuteDecisionResponse>(responseString);
            var meshTableList = JsonConvert.DeserializeObject<MeshTableList>(executeDecisionResponse.OutputState);
            if (meshTableList.MeshTable is not null)
            {
                _messages.Enqueue(new Message(batchCount, meshTableList.MeshTable));
                _logger.LogInformation("Completed execution request");
            }
            else
            {
                _logger.LogInformation("Found null response for case and did not add to queue");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError("Error executing batch: {Message}", ex.Message);
        }
        finally
        {
            _semaphore.Release();
        }
    }

    private static ExecuteDecisionRequest CreateDecisionRequest(string inputState)
    {
        var label = AppSettings.InRule.ProcessQualityMeasuresRCRS.Label;
        if (label is null or "")
            label = null;

        return new ExecuteDecisionRequest
        {
            RuleApp = new RuleApp
            {
                RepositoryRuleAppRevisionSpec = new RepositoryRuleAppRevisionSpec
                {
                    RuleApplicationName = AppSettings.InRule.ProcessQualityMeasuresRCRS.RuleApplicationName,
                    Label = label,
                    //Revision = AppSettings.InRule.ProcessQualityMeasuresRCRS.Revision
                }
            },
            DecisionName = AppSettings.InRule.ProcessQualityMeasuresRCRS.DecisionName,
            InputState = inputState
        };
    }
}
