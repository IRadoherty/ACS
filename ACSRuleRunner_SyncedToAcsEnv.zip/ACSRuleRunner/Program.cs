﻿using ACSRuleRunner.Services;
using DataAccess.DbAccess;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using Serilog.Events;

namespace ACSRuleRunner;
internal class Program
{
    public static AppSettings AppSettings { get; set; }
    public static CancellationToken CancellationToken { get; set; }
    private static async Task Main()
    {
        IConfiguration config = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json")
            .AddEnvironmentVariables()
            .Build();

        AppSettings = config.GetRequiredSection("AppSettings").Get<AppSettings>();

        Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(config)
            .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
            .CreateLogger();

        using var host = Host.CreateDefaultBuilder()
            .ConfigureServices((hostContext, services) =>
            {
                services.AddSingleton<RuleRunner>();
                services.AddTransient<IInRuleSaaSExecutionService, InRuleSaaSExecutionService>();
                services.AddTransient<IBatchService, BatchService>();
                services.AddSingleton<IOracleManager, OracleManager>();
                services.AddHttpClient("ExecuteDecision", client =>
                {
                    client.BaseAddress = new Uri(AppSettings.InRule.Development.ExecutionServiceUrl);
                    client.DefaultRequestHeaders.Add("Accept", "application/json");
                    client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization",
                        AppSettings.InRule.Development.ApiKey);
                });
            })
            .UseSerilog()
            .Build();

        var startTime = DateTime.UtcNow;
        Log.Logger.Information("{RuleRunner} Has Started - {startTime}", nameof(RuleRunner), startTime);

        await host.StartAsync();

        var ruleRunner = host.Services.GetRequiredService<RuleRunner>();
        ruleRunner.StartRuleRunner(true, CancellationToken);

        await host.WaitForShutdownAsync();

        Log.Logger.Information("{RuleRunner} Has Shutdown: {DateTime} Up time: {elapsedTime} minutes.", nameof(RuleRunner), DateTime.UtcNow, Math.Round(((DateTime.UtcNow - startTime).TotalMinutes), 2));
    }
}
