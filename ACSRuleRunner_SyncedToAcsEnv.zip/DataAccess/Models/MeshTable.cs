﻿namespace DataAccess.Models;

public class MeshTableList
{
    public List<MeshTable>? MeshTable { get; set; }
}
public class MeshTable
{
    public int MASTER_CASE_RECORD_ID { get; set; }
    public int MEASURE_KEY { get; set; }
    public int FACILITY_ID { get; set; }
    public string? ACCESSION_NBR { get; set; }
    public string? SEQUENCE_NBR { get; set; }
    public int DX_YEAR { get; set; }
    public string? PRIMARY_SITE { get; set; }
    //public string? MODIFIED_DATE { get; set; }
}
