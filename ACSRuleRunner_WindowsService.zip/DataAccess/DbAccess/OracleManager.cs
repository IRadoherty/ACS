﻿using System.Data;
using Dapper;
using Dapper.Oracle;
using DataAccess.Models;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;

namespace DataAccess.DbAccess;

public interface IOracleManager
{
    int GetCaseCount(string status);
    List<Cases> GetCaseData(int rows, string status);
    void InsertMeshTableSingle(MeshTable meshTable);
    void InsertMeshTableBulk(List<MeshTable> meshTable);
    void UpdateSnapShotCases(List<MeshTable> meshTable, string status);
    void UpdateSnapShotCase(MeshTable meshTable, string status);
}

public class OracleManager : IOracleManager
{
    private readonly IConfiguration _config;
    public OracleManager(IConfiguration config) => _config = config;

    public int GetCaseCount(string status)
    {
        using OracleConnection connection = new OracleConnection(_config.GetConnectionString("IR_RCRSQM_DEV"));
        string checkForNewCasesQuery = $"Select count(*) from snapshot_case where measure_status = '{status}'";
        connection.Open();
        //var results = connection.ExecuteScalar(checkForNewCasesQuery);
        using var command = new OracleCommand(checkForNewCasesQuery, connection);
        command.CommandType = CommandType.Text;
        var reader = command.ExecuteReader();
        var count = "";
        if (reader.Read())
            count = reader["COUNT(*)"].ToString();
        
        int.TryParse(count, out int Count);
        connection.Close();
        return Count;
    }

    public List<Cases> GetCaseData(int rows, string status)
    {
        using OracleConnection connection = new OracleConnection(_config.GetConnectionString("IR_RCRSQM_DEV"));
        string newCasesQuery =
        $"select distinct sc.MEASURE_GROUP,sd.MASTER_CASE_RECORD_ID,FACILITY_ID,ACCESSION_NBR,SEQUENCE_NBR,CLASS_OF_CASE_V12,DX_DATE,DX_YEAR,LAST_CONTACT_DT,NAACCR_VERSION,AGE,SEX,PRIMARY_SITE,BEHAVIOR_ICDO3,GRADE,HISTOLOGY_ICDO3,LATERALITY,BOOST_RX_MODALITY,CLIN_STAGE_GROUP,SRGY_PRIMARY_SITE_03,BRM_DT,CHEMO_DT,HORMONE_DT,CNCR_DIR_SURGERY_DT,RADIATION_DT,CS_SSF_1,CS_SSF_2,CS_SSF_6,CS_SSF_8,CS_SSF_25,CS_SSF_15,CS_TUMOR_SIZE,LOC_OF_RADIATION,PALLIATIVE_PROC,PATH_STAGE_GROUP,RADIATION_REG_RX_MOD,RADIATION_RX_VOL,REASON_NO_CNCR_SURGERY,REASON_NO_RADIATION,REG_NODES_EXAM,REG_NODES_POS,RX_DATE_DX_STG_PROC,RX_DATE_MOST_DEFIN_SURG,RX_DATE_RAD_ENDED,RX_DATE_SYSTEMIC,RX_HOSP_SURG_APP_2010,SCOPE_REG_LN_SRGY_03,SUMM_BRM,SUMM_CHEMO,SUMM_HORMONE,SUMM_NO_CNCR_SURGERY,SUMM_PALLIATIVE_PROC,SUMM_SRGY_PRIMARY_SITE_03,SUMM_SURGICAL_MARGINS,TNM_CLIN_M,TNM_CLIN_N,TNM_CLIN_T,TNM_PATH_M,TNM_PATH_N,TNM_PATH_T,VITAL_STATUS,TUMOR_SIZE_SUMMARY,AJCC_TNM_PATH_T,AJCC_TNM_PATH_N,AJCC_TNM_PATH_M,AJCC_TNM_PATH_STG_GRP,AJCC_TNM_CLIN_T,AJCC_TNM_CLIN_N,AJCC_TNM_CLIN_M,AJCC_TNM_CLIN_STG_GRP,AJCC_TNM_POST_M,AJCC_TNM_POST_N,AJCC_TNM_POST_STG_GRP,AJCC_TNM_POST_T,HER2_OVERALL_SUMM,ER_SUMMARY,PR_SUMMARY,ER_PERCENT_POS_OR_RNG,PR_PERCENT_POS_OR_RNG,PHASE_I_RT_MODALITY,PHASE_II_RT_MODALITY,PHASE_I_RT_VOLUME,PHASE_I_BEAM_TECH,PHASE_I_RT_TO_LN,FIGO_STAGE,SCHEMA_DISC_1,PSA,GLEASON_SCORE_CLIN,CRM,SLN_POS,NUM_PELV_NODES_POS,BRESLOW_THICKNESS,LN_FEM_ING_PARA_APELV,GRADE_CLIN,SCHEMA_DISC_2,BIRTH_DATE,SUMM_SYS_SEQ,SUMM_SR_SEQ,RX_HOSP_SURG,RX_SUMM_SURG from snapshot_case_det sd join snapshot_case sc on sc.master_Case_record_id = sd.master_case_record_id where exists (select null from snapshot_case cm where cm.master_Case_record_id = sd.master_Case_record_id and cm.measure_status='{status}') and rownum <= {rows}";

        return connection.Query<Cases>(newCasesQuery).ToList();
    }
    public void InsertMeshTableSingle(MeshTable meshTable)
    {
        using OracleConnection connection = new OracleConnection(_config.GetConnectionString("IR_RCRSQM_DEV"));

        const string sql = "INSERT INTO MESH_IR ( MASTER_CASE_RECORD_ID,MEASURE_KEY,FACILITY_ID,ACCESSION_NBR,SEQUENCE_NBR,DX_YEAR,PRIMARY_SITE) values(:MASTER_CASE_RECORD_ID, :MEASURE_KEY, :FACILITY_ID, :ACCESSION_NBR, :SEQUENCE_NBR, :DX_YEAR, :PRIMARY_SITE)";

        OracleDynamicParameters parameters = new OracleDynamicParameters();
        parameters.Add("MASTER_CASE_RECORD_ID", meshTable.MASTER_CASE_RECORD_ID);
        parameters.Add("MEASURE_KEY", meshTable.MEASURE_KEY);
        parameters.Add("FACILITY_ID", meshTable.FACILITY_ID);
        parameters.Add("ACCESSION_NBR", meshTable.ACCESSION_NBR);
        parameters.Add("SEQUENCE_NBR", meshTable.SEQUENCE_NBR);
        parameters.Add("DX_YEAR", meshTable.DX_YEAR);
        parameters.Add("PRIMARY_SITE", meshTable.PRIMARY_SITE);
        connection.Execute(sql, parameters);
    }

    public void InsertMeshTableBulk(List<MeshTable> meshTable)
    {
        using OracleConnection connection = new OracleConnection(_config.GetConnectionString("IR_RCRSQM_DEV"));
        int[] masterCaseRecordIds = new int[meshTable.Count];
        int[] measureKeys = new int[meshTable.Count];
        int[] facilityIds = new int[meshTable.Count];
        string?[] accessionNbrs = new string[meshTable.Count];
        string?[] sequenceNbrs = new string[meshTable.Count];
        int[] dxYears = new int[meshTable.Count];
        string?[] primarySites = new string[meshTable.Count];

        int i = 0;
        foreach (var meshData in meshTable)
        {
            masterCaseRecordIds[i] = meshData.MASTER_CASE_RECORD_ID;
            measureKeys[i] = meshData.MEASURE_KEY;
            facilityIds[i] = meshData.FACILITY_ID;
            accessionNbrs[i] = meshData.ACCESSION_NBR;
            sequenceNbrs[i] = meshData.SEQUENCE_NBR;
            dxYears[i] = meshData.DX_YEAR;
            primarySites[i] = meshData.PRIMARY_SITE;
            ++i;
        }

        const string sql = "INSERT INTO MESH_IR ( MASTER_CASE_RECORD_ID,MEASURE_KEY,FACILITY_ID,ACCESSION_NBR,SEQUENCE_NBR,DX_YEAR,PRIMARY_SITE) values(:MASTER_CASE_RECORD_ID, :MEASURE_KEY, :FACILITY_ID, :ACCESSION_NBR, :SEQUENCE_NBR, :DX_YEAR, :PRIMARY_SITE)";

        
        var parameters = new OracleDynamicParameters { ArrayBindCount = meshTable.Count };
        parameters.Add("MASTER_CASE_RECORD_ID", masterCaseRecordIds, OracleMappingType.Int32, ParameterDirection.Input);
        parameters.Add("MEASURE_KEY", measureKeys, OracleMappingType.Int32, ParameterDirection.Input);
        parameters.Add("FACILITY_ID", facilityIds, OracleMappingType.Int32, ParameterDirection.Input);
        parameters.Add("ACCESSION_NBR", accessionNbrs, OracleMappingType.NVarchar2, ParameterDirection.Input, 9);
        parameters.Add("SEQUENCE_NBR", sequenceNbrs, OracleMappingType.NVarchar2, ParameterDirection.Input, 2);
        parameters.Add("DX_YEAR", dxYears, OracleMappingType.Int32, ParameterDirection.Input);
        parameters.Add("PRIMARY_SITE", primarySites, OracleMappingType.NVarchar2, ParameterDirection.Input, 4);
        connection.Execute(sql, parameters);
    }
    public void UpdateSnapShotCases(List<MeshTable> meshTable, string status)
    {
        using OracleConnection connection = new OracleConnection(_config.GetConnectionString("IR_RCRSQM_DEV"));
        int[] masterCaseRecordIds = new int[meshTable.Count];
        int i = 0;
        foreach (var meshData in meshTable)
        {
            masterCaseRecordIds[i] = meshData.MASTER_CASE_RECORD_ID;
            ++i;
        }

        string sql = $"UPDATE SNAPSHOT_CASE SET MEASURE_STATUS = '{status}' WHERE MASTER_CASE_RECORD_ID = :MASTER_CASE_RECORD_ID";

        var parameters = new OracleDynamicParameters { ArrayBindCount = meshTable.Count };
        parameters.Add("MASTER_CASE_RECORD_ID", masterCaseRecordIds, OracleMappingType.Int32, ParameterDirection.Input);
        connection.Execute(sql, parameters);
    }
    public void UpdateSnapShotCase(MeshTable meshTable, string status)
    {
        using OracleConnection connection = new OracleConnection(_config.GetConnectionString("IR_RCRSQM_DEV"));
        int[] masterCaseRecordIds = new int[1];
        masterCaseRecordIds[0] = meshTable.MASTER_CASE_RECORD_ID;

        string sql = $"UPDATE SNAPSHOT_CASE SET MEASURE_STATUS = '{status}' WHERE MASTER_CASE_RECORD_ID = :MASTER_CASE_RECORD_ID";

        var parameters = new OracleDynamicParameters { ArrayBindCount = 1 };
        parameters.Add("MASTER_CASE_RECORD_ID", masterCaseRecordIds, OracleMappingType.Int32, ParameterDirection.Input);
        connection.Execute(sql, parameters);
    }

}
