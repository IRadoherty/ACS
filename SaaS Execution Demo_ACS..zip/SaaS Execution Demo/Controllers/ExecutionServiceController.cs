﻿
using System.Net.Http.Headers;
using System.Text;
using SaaS_Execution_Demo.Models.Requests;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SaaS_Execution_Demo.Services;


namespace SaaS_Execution_Demo.Controllers
{
    [EnableCors("EnableCORS")]
    [ApiController]
    public class ExecutionServiceController : ControllerBase
    {
        private readonly ExecutionService _irServerService;

        public ExecutionServiceController(ExecutionService irServerService)
        {
            _irServerService = irServerService;
        }

        /// <summary>
        /// Post an Apply Rules request with an authorization header.
        /// </summary>
        /// <param name="Authorization">Your API Key as an authorization header value</param>
        /// <param name="ExecutionServiceUrl">The URL of the execution service</param>
        /// <param name="request">The rule request body for the apply rules request</param>
        /// <returns name="request">The rule request body for the apply rules request</returns>
        /// <remarks>
        /// Multiplication ApplyRules Post Request:
        /// 
        ///     {
        ///        "RuleApp":{
        ///            "RepositoryRuleAppRevisionSpec":{
        ///                "RuleApplicationName": "MultiplicationApp"
        ///            }
        ///        },
        ///        "EntityName": "MultiplicationProblem",
        ///        "EntityState": "{'FactorA': 12.4, 'FactorB': 3.1}"
        ///     }
        /// </remarks>
        /// <returns>A newly created employee</returns>
        /// <response code="200">Returns a successful execution response</response>
        /// <response code="500">Some error has occurred during rule execution</response>
        [HttpPost(nameof(ApplyRules))]
        [Route("ApplyRules")]
        [ProducesResponseType(200)]
        [ProducesResponseType(500)]
        [Produces("application/json")]
        [Consumes("application/json")]
        public async Task<IResult> ApplyRules( RuleRequest request)
        {
            try
            {
                return Results.Ok(await _irServerService.irServerPost());
            }
            catch (Exception ex)
            {
                return Results.Problem(ex.Message);
            }

        }

    }
}
