﻿namespace SaaS_Execution_Demo.Models
{
    public class MeshTable
    {
        public int RECORD_ID { get; set; }
        public int MEASURE_KEY { get; set; }
        public int FACILITY_ID { get; set; }
        public int DX_YEAR { get; set; }
        public int ACCESSION_NBR { get; set; }
        public int SEQUENCE_NBR { get; set; }
        public string PRIMARY_SITE { get; set; }
    }

    public class MeshTableRoot
    {
        public List<MeshTable> MeshTable { get; set; }
    }
}