﻿using SaaS_Execution_Demo.Models.Requests;

namespace SaaS_Execution_Demo.Models.Responses
{
    public class RuleExecution
    {
        public class DecisionExecutionResponse : ExecutionResponse
        {
            public string OutputState { get; set; }
        }
        public class ExecutionResponse
        {
            public Activenotification[] ActiveNotifications { get; set; }
            public Activevalidation[] ActiveValidations { get; set; }
            public bool HasRuntimeErrors { get; set; }
            public Ruleexecutionlog RuleExecutionLog { get; set; }
        }
        public class RuleExecutionResponse : ExecutionResponse
        {
            public string EntityState { get; set; }
        }
        public class Activenotification
        {
            public string ElementId { get; set; }
            public bool IsActive { get; set; }
            public string Message { get; set; }
            public string NotificationType { get; set; }
        }
        public class Activevalidation
        {
            public string ElementIdentifier { get; set; }
            public string InvalidMessageText { get; set; }
            public bool IsValid { get; set; }
            public Reason[] Reasons { get; set; }
        }
        public class Reason
        {
            public string FiringRuleId { get; set; }
            public string MessageText { get; set; }
        }
        public class Ruleexecutionlog
        {
            public Message[] Messages { get; set; }
            public long TotalEvaluationCycles { get; set; }
            public string TotalExecutionTime { get; set; }
            public int TotalTraceFrames { get; set; }
        }
        public class Message
        {
            public string Description { get; set; }
            public int ChangeType { get; set; }
            public int CollectionCount { get; set; }
            public string CollectionId { get; set; }
            public string MemberId { get; set; }
            public int MemberIndex { get; set; }
        }

    }
}
