﻿using System.Net;
using System.Net.Http.Headers;
using System.Text;
using SaaS_Execution_Demo.Models.Requests;
using SaaS_Execution_Demo.Models.Responses;
using Newtonsoft.Json;
using SaaS_Execution_Demo.Models;

namespace SaaS_Execution_Demo.Services
{
    public class ExecutionService
    {
        public async Task<MeshTableRoot> irServerPost()
        {

            var executionServiceUrl = "https://acs-test-execute.inrulecloud.com/HttpService.svc/ExecuteDecision";
            var authorization = "APIKEY HTRT5FACE39jRERQA5T65D4J983Y4Q28";
            var ruleAppName = "TestQMRuleApp";
            var decisionName = "QualityMeasure";
            var inputState =
                "{\"MeasureRecord\": {\"Cases\":[{\"RECORD_ID\":100039917,\"NAACCR_VERSION\":160,\"FACILITY_ID\":6860395,\"SEX\":2,\"AGE\":53,\"BIRTH_DATE\":\"19640401\",\"ACCESSION_YR\":2017,\"DX_YEAR\":2017,\"DX_DATE\":\"20171001\",\"PRIMARY_SITE\":\"C505\",\"LATERALITY\":2,\"HISTOLOGY_ICDO3\":8500,\"BEHAVIOR_ICDO3\":3,\"GRADE\":2,\"ACCESSION_NBR\":201720621,\"SEQUENCE_NBR\":0,\"CLASS_OF_CASE_V12\":11,\"RX_HOSP_SURG_APP_2010\":5,\"SRGY_PRIMARY_SITE_03\":22,\"SCOPE_REG_LN_SRGY_03\":2,\"PALLIATIVE_PROC\":0,\"REG_NODES_POS\":0,\"REG_NODES_EXAM\":3,\"TNM_PATH_T\":\"p1B\",\"TNM_PATH_N\":\"p0I-\",\"TNM_PATH_M\":\"c0\",\"PATH_STAGE_GROUP\":\"1A\",\"TNM_CLIN_T\":\"c1B\",\"TNM_CLIN_N\":\"c0\",\"TNM_CLIN_M\":\"c0\",\"CLIN_STAGE_GROUP\":\"1A\",\"CS_TUMOR_SIZE\":999,\"CS_SSF_1\":10,\"CS_SSF_2\":10,\"CS_SSF_6\":0,\"CS_SSF_8\":999,\"CS_SSF_15\":20,\"CS_SSF_25\":988,\"CNCR_DIR_SURGERY_DT\":\"20171001\",\"RX_DATE_MOST_DEFIN_SURG\":\"20171001\",\"RADIATION_DT\":\"20171001\",\"RX_DATE_RAD_ENDED\":\"20171001\",\"RX_DATE_SYSTEMIC\":\"20171001\",\"CHEMO_DT\":\"20171001\",\"HORMONE_DT\":\"20171001\",\"BRM_DT\":\"20171001\",\"RX_DATE_DX_STG_PROC\":\"20171001\",\"SUMM_SRGY_PRIMARY_SITE_03\":22,\"SUMM_SURGICAL_MARGINS\":0,\"REASON_NO_CNCR_SURGERY\":0,\"SUMM_NO_CNCR_SURGERY\":2,\"SUMM_PALLIATIVE_PROC\":0,\"SUMM_SR_SEQ\":3,\"SUMM_CHEMO\":0,\"SUMM_HORMONE\":0,\"SUMM_BRM\":0,\"REASON_NO_RADIATION\":0,\"RADIATION_RX_VOL\":18,\"LOC_OF_RADIATION\":4,\"RADIATION_REG_RX_MOD\":50,\"BOOST_RX_MODALITY\":0,\"SUMM_SYS_SEQ\":0,\"LAST_CONTACT_DT\":\"20171001\",\"VITAL_STATUS\":1,\"TUMOR_SIZE_SUMMARY\":8,\"AJCC_TNM_PATH_T\":\"text\",\"AJCC_TNM_PATH_N\":\"text\",\"AJCC_TNM_PATH_M\":\"text\",\"AJCC_TNM_PATH_STG_GRP\":\"text\",\"AJCC_TNM_CLIN_T\":\"text\",\"AJCC_TNM_CLIN_N\":\"text\",\"AJCC_TNM_CLIN_M\":\"text\",\"AJCC_TNM_CLIN_STG_GRP\":\"text\",\"SCHEMA_DISC_1\":1,\"SCHEMA_DISC_2\":4,\"AJCC_TNM_POST_M\":\"text\",\"AJCC_TNM_POST_N\":\"text\",\"AJCC_TNM_POST_STG_GRP\":\"text\",\"AJCC_TNM_POST_T\":\"text\",\"DATE_MODIFIED\":\"20220101\"}]}}";

            var decisionRequest = new ExecuteDecisionRequest()
            {
                RuleApp = new RuleApp
                {
                    RepositoryRuleAppRevisionSpec = new RepositoryRuleAppRevisionSpec()
                    {
                        RuleApplicationName = ruleAppName
                    }
                },
                DecisionName = decisionName,
                InputState = inputState
            };

            var result = await irServerPost(decisionRequest, executionServiceUrl, authorization);

            return result;

        }
     
        public async Task<MeshTableRoot> irServerPost(ExecuteDecisionRequest decisionRequest, string executionServiceUrl, string authorization)
        {
            using var client = new HttpClient();
            client.BaseAddress = new Uri(executionServiceUrl);
            client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", authorization);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var requestJson = JsonConvert.SerializeObject(decisionRequest);
            var content = new StringContent(requestJson, Encoding.UTF8, "application/json");
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            var response = await client.PostAsync(executionServiceUrl, content);
            var outputState = new MeshTableRoot();

            // Log response step
            // If not valid response code this returns without mapping the response any further
            if (!response.IsSuccessStatusCode) return outputState;

            var responseString = response.Content.ReadAsStringAsync();

            // Convert rule response to json object ( .Result may or may not be needed depending on C# language. If an error remove .Result
            // var responseJSON = JsonConvert.DeserializeObject<RuleExecution.DecisionExecutionResponse>(responseString);
            var responseJSON = JsonConvert.DeserializeObject<RuleExecution.DecisionExecutionResponse>(responseString.Result);

            // Convert output state from Decision response
            outputState = JsonConvert.DeserializeObject<MeshTableRoot>(responseJSON.OutputState);
            return outputState;
        }
    }
}